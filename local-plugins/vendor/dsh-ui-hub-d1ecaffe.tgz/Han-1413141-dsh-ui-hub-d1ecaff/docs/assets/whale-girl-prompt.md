# 首图提示词 · Whale Girl (鲸鱼娘) — dsh-ui-hub

> 把下面任一提示词投给你常用的绘图模型（Midjourney / DALL·E / Stable Diffusion / 即梦等），
> 生成后保存为 `docs/assets/whale-girl.png`，并建议另存 WebP 版本 `docs/assets/whale-girl.webp`。
> 生成图请使用 3:2 或 16:9 横构图，留出左侧 1/3 用于标题排版。

## 中文提示词（推荐主用）

一位可爱的鲸鱼娘（鲸鱼拟人少女），银蓝色渐变长发，发间别着发光的小鲸鱼发饰，穿深蓝与白色相间的科技风连衣裙，袖口和裙摆有鲸鱼尾巴纹样。她悬浮在画面右侧，正用手指拖拽一个发光的半透明悬浮面板：面板上排列着几块带开关的 UI 卡片（圆形按钮、迷你图标、折线图表、输入框），其中一块卡片右下角有蓝色圆形拖拽手柄，卡片周围有青色虚线框，表示「可拖拽调整位置与大小」。面板顶部有「官方 UI / 插件 UI」两个折叠标签，下方是整齐的右对齐 UI 队列。

背景是深色科技感聊天界面：左侧有侧边栏与聊天输入框，中间漂浮着胶囊按钮、图表卡片等插件控件，控件之间用淡青色参考线与间距标注连成整齐网格，暗示「自动排布与碰撞避让」。整体色调深蓝、藏青、霓虹青与品蓝渐变，带细小的粒子光点与全息投影感。角色表情温柔自信，眼睛是海蓝色，看向自己整理的界面，画面干净、留白充足、主体突出。

构图：电影感 3:2 横构图，鲸鱼娘在画面右侧，面板居中偏右，左侧留白用于放标题文字。风格：高质量 2D 赛璐璐 + 轻微厚涂，精致的透明材质与发光边缘，现代产品宣传插画，干净矢量感 UI 元素，4K，细节丰富，柔和体积光，无文字水印。负面提示：低质量、多余手指、文字乱码、杂乱背景、遮挡主体。

## English prompt

A cute whale girl (anthropomorphic whale mascot), long silver-blue gradient hair with a tiny glowing whale hairpin, wearing a tech-inspired navy and white dress with whale-tail patterns on the cuffs and hem. She floats on the right side of the frame, dragging a glowing semi-transparent floating panel with one finger: the panel holds several UI cards with switches (round buttons, mini icons, a line chart, an input field). One card has a small blue circular drag handle at its bottom-right corner and a cyan dashed outline, indicating "drag to move and resize". At the top of the panel there are two collapsible tabs labeled "Official UI / Plugin UI", and below them a tidy right-aligned queue of widgets.

Background: a dark futuristic chat interface with a sidebar and a composer on the left, floating pill buttons and chart cards in the middle, connected by faint cyan alignment guides with even spacing — suggesting automatic arrangement and collision avoidance. Palette: deep blue, navy, neon cyan, and indigo gradients with tiny glowing particles and a holographic feel. The whale girl looks gentle and confident, sea-blue eyes, gazing at the interface she just organized. Clean composition with generous negative space on the left for title text.

Cinematic 3:2 landscape composition, whale girl on the right, panel center-right, empty left third for text. Style: high-quality 2D cel-shading with light painterly shading, refined translucent materials, glowing edges, modern product illustration, crisp vector-like UI elements, 4K, rich detail, soft volumetric light, no watermark, no text gibberish. Negative: low quality, extra fingers, garbled text, cluttered background, obscured subject.
